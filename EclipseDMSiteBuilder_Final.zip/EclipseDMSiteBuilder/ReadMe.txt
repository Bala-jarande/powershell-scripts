This package of scripts was designed to automate the creation of sites collections for the Eclipse SharePoint integration solutions in accordance with the site collection, URL, and database design that was determined during the project's design phase.

Due to issues with how PowerShell caches objects, this package is a group of scripts that are all run from a master build script.  This eliminates issues around the caching issue that was preventing the template from being discovered and applied properly when running it as a single, unified script.

This script should be able to unzipped and run from any directory on the server, but if you encounter issues, try to run it from a location that does not contain spaces withing the file path.

Once unzipped, update the values in Parameters.ps1 as appropriate for the environment and what is to be built.

Open a powershell window as an Administrator and execute MasterBuildScript.ps1