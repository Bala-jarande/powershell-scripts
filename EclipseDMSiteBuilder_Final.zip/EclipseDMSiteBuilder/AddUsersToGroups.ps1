﻿###########################################################################
#
# NAME: AddUsersToGroups
#
# AUTHOR:  koltist
#
# COMMENT: Adds users/groups from the parameters file to the designated sharepoint groups
#
# VERSION HISTORY:
# 1.0 1/24/2012 - Initial release
#
###########################################################################

$Host.Runspace.ThreadOptions = "ReuseThread"
Set-ExecutionPolicy unrestricted
if ((Get-PSSnapin -Name Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue) -eq $null)
{
	Add-PSSnapin Microsoft.SharePoint.PowerShell
}

$path = Split-Path $myInvocation.MyCommand.Path
$globals = Join-Path $path Parameters.ps1
. $globals
cd $path

#region Functions

Function AddUsersToGroup
{
	param ($spWeb, $arrayOfUsers, $sharePointGroup)
	
	$group = $web.SiteGroups[$sharePointGroup]
	foreach ($user in $arrayOfUsers)
	{
		$group.Users.Add($user, "", "", "")
	}	
}

Function AddSiteCollectionAdministrators
{
	param ($spWeb, $arrayOfSiteCollectionAdministrators)
	
	foreach ($admin in $arrayOfSiteCollectionAdministrators)
	{
		
		$spWeb.AllUsers.Add($admin, "", "", "")
		$user = $spWeb.EnsureUser($admin)
		$user.IsSiteAdmin = $true
		$user.Update()
	}	
}


#endregion

foreach ($m in $monthArray)
{
	#$webURL = "$webAppURL" + "`/" + "$yearToCreate" + "`/" + "$m" #Modify
    $webURL = "$webAppURL" + "`/" + "Sites" + "/" + "EclipseDM" + "$yearToCreate" + "$m" 
	Write-Host "Adding users to groups on $webURL"
	$web = Get-SPWeb $webURL
	$visitorsGroup = $web.AssociatedVisitorGroup
	$membersGroup = $web.AssociatedMemberGroup
	$ownersGroup = $web.AssociatedOwnerGroup
	Write-Host "Adding to $visitorsGroup"
	#AddUsersToGroup $web $visitors $visitorsGroup
	Write-Host "Adding to $membersGroup"
	#AddUsersToGroup $web $members $membersGroup
	Write-Host "Adding to $ownersGroup"
	#AddUsersToGroup $web $owners $ownersGroup
	Write-Host "Adding site collection administrators"
	AddSiteCollectionAdministrators $web $siteCollectionAdministrators
	
	$web.Dispose()
}