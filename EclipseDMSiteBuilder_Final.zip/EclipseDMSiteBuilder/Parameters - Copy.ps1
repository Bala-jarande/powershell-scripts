﻿#WebApp to perform build upon
$Global:webAppURL = "http://eclipsedm.willis.com"
#Database alias or server that will house the databases
$Global:dbServer = "sp2010-sql"
#Database prefix that will apply to all the databases this script will create
$Global:contentDBPrefix = "SP2010_DM870_EclipseDM"

#Year to build databases for, this will be used to create a managed path and as part of database names
$Global:yearToCreate = "2013"
#Months that need to be build for the above year, users as part of URL, to generate site name, and to generate database names
$Global:monthArray = "01","02","03","04","05","06","07","08","09","10","11","12"
$Global:solutionName = "EclipseDMSite.wsp"
$Global:templateName = "EclipseDMSite"
$Global:ownerAccount = "int\dlemosk"

#Users and groups that should be added to the appopriate SharePoint groups on each site
#Use "domain\username" or "domain\groupname" with commas, if no groups are to be added, use @() to specify a null array of values
$Global:visitors = @()
$Global:members = "int\w-eb-users-g","int\svc-w-eclipse","int\svc-w-spuploader"
$Global:owners = "int\UKAppSupp-Eclipse"
$Global:siteCollectionAdministrators = @()