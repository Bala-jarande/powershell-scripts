﻿###########################################################################
#
# NAME: CreateSitesInExistingDatabases
#
# AUTHOR:  koltist
#
# COMMENT: 
# 7/31/2020 - Done the changes to support new EclipseDM structure on SharePoint 2019
#
# VERSION HISTORY:
# 1.0 1/24/2012 - Initial release
# 2.0 7/31/2020 - Update by Rajani Kant
#
###########################################################################

$Host.Runspace.ThreadOptions = "ReuseThread"
Set-ExecutionPolicy unrestricted
if ((Get-PSSnapin -Name Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue) -eq $null)
{
	Add-PSSnapin Microsoft.SharePoint.PowerShell
}

$path = Split-Path $myInvocation.MyCommand.Path
$globals = Join-Path $path Parameters.ps1
. $globals
cd $path

Write-Host "Building sandbox solution path..."
$solutionPath = Join-Path $path $solutionName
Write-Host "Solution path is $solutionPath"

#region Create managed path

#Get Web App
$webApp = Get-SPWebApplication -Identity $webAppURL

#Create Managed Path is it doesn't exist
#Write-Host -ForegroundColor White "Setting up wildcard managed path `"$yearToCreate`" on `"$webAppUrl`""
#New-SPManagedPath -RelativeURL $yearToCreate -WebApplication $webApp -ErrorAction SilentlyContinue | Out-Null

#endregion

#Region Create Content Databases and site collections, upload solution
foreach ($m in $monthArray)
{
	#Build site title
	$firstOfMonth = "$m" + "01" + "$yearToCreate"
	$tempDate = [datetime]::ParseExact($firstOfMonth, "MMddyyyy", $null)	
	$scTitle = (Get-Date $tempDate -Format "MMMM yyyy").ToString()
	
	#Create site collection and place in content database
	$scURL = "$webAppURL" + "`/" + "Sites" + "/" + "EclipseDM" + "$yearToCreate" + "$m" 
	$siteCollection = New-SPSite -Url $scURL -Name $scTitle -OwnerAlias $ownerAccount
	Write-Host "Site Collection created at $scURL."
	
	#Upload solution and activate
	Add-SPUserSolution -LiteralPath $solutionPath -Site $siteCollection
	Install-SPUserSolution -Identity $solutionName -Site $siteCollection
	$solution = Get-SPUserSolution $solutionName -Site $siteCollection
	Write-Host "Waiting for solution to activate on $scURL..."
	do
	{
		Start-Sleep -Seconds 5
	}
	until ($solution.Status -eq "Activated")
	Write-Host "Solution activated on $scURL."
}
Write-Host "Site collection creation and solution activation complete."
#endregion