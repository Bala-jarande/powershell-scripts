﻿###########################################################################
#
# NAME: AddGroupsToSites
#
# AUTHOR:  koltist
#
# COMMENT: Builds the standard sharepoint groups to each site.
#
# VERSION HISTORY:
# 1.0 1/24/2012 - Initial release
#
###########################################################################

$Host.Runspace.ThreadOptions = "ReuseThread"
Set-ExecutionPolicy unrestricted
if ((Get-PSSnapin -Name Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue) -eq $null)
{
	Add-PSSnapin Microsoft.SharePoint.PowerShell
}

$path = Split-Path $myInvocation.MyCommand.Path
$globals = Join-Path $path Parameters.ps1
. $globals
cd $path

#Add Groups to site
foreach ($m in $monthArray)
{
	#$webURL = "$webAppURL" + "`/" + "$yearToCreate" + "`/" + "$m" #Modify
    $webURL = "$webAppURL" + "`/" + "Sites" + "/" + "EclipseDM" + "$yearToCreate" + "$m" 
	Write-Host "Adding groups to $webURL"
	$web = Get-SPWeb $webURL
	$webTitle = $web.Title
	$web.AssociatedVisitorGroup = $null
	$web.Update()
    $ownerAccount = $web.EnsureUser($ownerAccount)
	$web.CreateDefaultAssociatedGroups($ownerAccount, $ownerAccount, $webTitle)
	#fixes a bug in the CreateDefaultAssociatedGroups command....
	$web.Properties["vti_associatedvisitorgroup"] = $web.AssociatedVisitorGroup.Id.ToString() # Need to check
	$web.Properties.Update()
	$web.Update()	
	Write-Host "Group creation on $webURL complete"	
	$web.Dispose()
}