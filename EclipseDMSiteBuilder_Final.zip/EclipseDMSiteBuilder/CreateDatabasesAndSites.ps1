﻿###########################################################################
#
# NAME: CreateDatabasesAndSites
#
# AUTHOR:  koltist
#
# COMMENT: Creates a database and site collection for each month that is being provisioned
# 7/31/2020 - Done the changes to support new EclipseDM structure on SharePoint 2019
#
# VERSION HISTORY:
# 1.0 1/24/2012 - Initial release
# 2.0 7/31/2020 - Update by Rajani Kant
#
###########################################################################

$Host.Runspace.ThreadOptions = "ReuseThread"
Set-ExecutionPolicy unrestricted
if ((Get-PSSnapin -Name Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue) -eq $null)
{
	Add-PSSnapin Microsoft.SharePoint.PowerShell
}


$path = Split-Path $myInvocation.MyCommand.Path
$globals = Join-Path $path Parameters.ps1
. $globals
cd $path

Write-Host "Building sandbox solution path..."
$solutionPath = Join-Path $path $solutionName
Write-Host "Solution path is $solutionPath"

#region Create managed path

#Get Web App
$webApp = Get-SPWebApplication -Identity $webAppURL

#Create Managed Path is it doesn't exist
#Write-Host -ForegroundColor White "Setting up wildcard managed path `"$yearToCreate`" on `"$webAppUrl`""
#New-SPManagedPath -RelativeURL $yearToCreate -WebApplication $webApp -ErrorAction SilentlyContinue | Out-Null #Modify

#endregion

#Region Create Content Databases and site collections, upload solution
foreach ($m in $monthArray)
{
	#Create content database
	$dbName = $contentDBPrefix + "_" + $yearToCreate + $m
	#Start-Sleep -s 5
	#$contentDB = New-SPContentDatabase -DatabaseServer "SharePoint2019V" -WebApplication "http://sharepoint2019v:23976" -Name "SP2019_DM870_EclipseDM_2012_01" -WarningSiteCount 0 -MaxSiteCount 1
    $contentDB = New-SPContentDatabase -DatabaseServer $dbServer -WebApplication $webAppURL -Name $dbName -WarningSiteCount 0 -MaxSiteCount 1
	foreach ($s in $shellAdmins)
	{
		Add-SPShellAdmin -Database $contentDB -UserName $s
	}
	Write-Host "Database $dbName created."
	
	#Build site title
	$firstOfMonth = "$m" + "01" + "$yearToCreate"
	$tempDate = [datetime]::ParseExact($firstOfMonth, "MMddyyyy", $null)	
	$scTitle = (Get-Date $tempDate -Format "MMMM yyyy").ToString()
	
	#Create site collection and place in content database
	#$scURL = "$webAppURL" + "`/" + "$yearToCreate" + "`/" + "$m" # Modify
    $scURL = "$webAppURL" + "`/" + "Sites" + "/" + "EclipseDM" + "$yearToCreate" + "$m" 
	$siteCollection = New-SPSite -Url $scURL -Name $scTitle -ContentDatabase $contentDB -OwnerAlias $ownerAccount
	Write-Host "Site Collection created at $scURL."
	
	#Upload solution and activate
	Add-SPUserSolution -LiteralPath $solutionPath -Site $siteCollection
	Install-SPUserSolution -Identity $solutionName -Site $siteCollection
	$solution = Get-SPUserSolution $solutionName -Site $siteCollection
	Write-Host "Waiting for solution to activate on $scURL..."
	do
	{
		Start-Sleep -Seconds 2
	}
	until ($solution.Status -eq "Activated")
	Write-Host "Solution activated on $scURL."
}
Write-Host "Site collection creation and solution activation complete."
#endregion