﻿###########################################################################
#
# NAME: ApplyTemplateToSite
#
# AUTHOR:  koltist
#
# COMMENT: Applies the sandbox solution site template that was uploaded to the designated site
#
# VERSION HISTORY:
# 1.0 1/24/2012 - Initial release
#
###########################################################################

$Host.Runspace.ThreadOptions = "ReuseThread"
Set-ExecutionPolicy unrestricted
if ((Get-PSSnapin -Name Microsoft.SharePoint.PowerShell -ErrorAction SilentlyContinue) -eq $null)
{
	Add-PSSnapin Microsoft.SharePoint.PowerShell
}

$path = Split-Path $myInvocation.MyCommand.Path
$globals = Join-Path $path Parameters.ps1
. $globals
cd $path

Write-Host "Applying WebTemplate to sites..."
foreach ($m in $monthArray)
{
	#$scURL = "$webAppURL" + "`/" + "$yearToCreate" + "`/" + "$m" # Modify
    $scURL = "$webAppURL" + "`/" + "Sites" + "/" + "EclipseDM" + "$yearToCreate" + "$m" 
	Write-Host "Looking for template on $scURL..."
	
	#Find installed template
	$web = Get-SPWeb $scURL
	$loc = [System.Int32]::Parse(1033)
	$webTemplates = $web.GetAvailableWebTemplates($loc, $true)
	$webTemplates | Where {$_.Title -eq $templateName} | ForEach-Object {$webTemplate = $_}
	if($webTemplate)
	{
		#Apply template
		$web.ApplyWebTemplate($webTemplate)
		Write-Host "$templateName applied to $scURL"
	}
	else
	{
		Write-Host "$templateName not found on $scURL, apply template manually."
	}
}