﻿###########################################################################
#
# NAME: 
#
# AUTHOR:  koltist
#
# COMMENT: 
# 7/31/2020 - Done the changes to support new EclipseDM structure on SharePoint 2019
#
# VERSION HISTORY:
# 1.0 1/24/2012 - Initial release
# 2.0 7/31/2020 - Update by Rajani Kant
#
###########################################################################

$Host.Runspace.ThreadOptions = "ReuseThread"

function Test-Administrator
{
	$user = [Security.Principal.WindowsIdentity]::GetCurrent() 
	(New-Object Security.Principal.WindowsPrincipal $user).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
}

if (Test-Administrator)
{
	Set-ExecutionPolicy unrestricted

	$path = Split-Path $myInvocation.MyCommand.Path
	cd $path

	$choiceCaption = "Select script type"
	$choiceMessage = "Select lite or full.  Lite creates sites in existing databases (useful for pre-production).  Full creates sites in new content databases (for IAT and Production use)"
	$lite = New-Object System.Management.Automation.Host.ChoiceDescription "&Lite", "Creates site collections in existing databases via round robin, use this option for DEV and QA"
	$full = New-Object System.Management.Automation.Host.ChoiceDescription "&Full", "Creates site collections in new databases that will be created, use this option for IAT and PPOD"
	$choices = [System.Management.Automation.Host.ChoiceDescription[]]($lite,$full)
	$answer = $Host.UI.PromptForChoice($choiceCaption, $choiceMessage, $choices, 1)

	switch ($answer)
	{
		0 {
			Write-Host "Executing lite script"
			$siteCreationScript = Join-Path $path CreateSitesInExistingDatabases.ps1
			Write-Host "Creating sites in existing databases and uploading templates..."
			Start-Process powershell -ArgumentList "$siteCreationScript" -Verb RunAs -Wait
		}
		1 {
			Write-Host "Executing full script"
			$siteCreationScript = Join-Path $path CreateDatabasesAndSites.ps1
			Write-Host "Creating sites, databases, and uploading templates..."
			Start-Process powershell -ArgumentList "$siteCreationScript" -Verb RunAs -Wait
		}
	}

	$applyTemplateScript = Join-Path $path ApplyTemplateToSites.ps1
	Write-Host "Applying template to sites..."
	#Start-Process powershell -ArgumentList "$applyTemplateScript" -Verb RunAs -Wait

	$addGroupsScript = Join-Path $path AddGroupsToSites.ps1
	Write-Host "Adding groups to sites..."
	Start-Process powershell -ArgumentList "$addGroupsScript" -Verb RunAs -Wait

	$addUsersScript = Join-Path $path AddUsersToGroups.ps1
	Write-Host "Applying users to groups..."
	Start-Process powershell -ArgumentList "$addUsersScript" -Verb RunAs -Wait
}
else
{
	Write-Host
}